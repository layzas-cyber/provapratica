    // ================== CONFIGURAÇÃO ==================
    // Altere para o endereço/porta do seu servidor Express.
    const API_URL = "http://localhost:3000";
    const ROTA = `${API_URL}/objetos`;

    // Campos esperados no JSON: id, descricao, categoria, local, data_registro, situacao
    // situacao: "disponível" ou "devolvido"

    let objetos = [];

    const $ = (id) => document.getElementById(id);
    const form = $("form");

    // ================== UTILITÁRIOS ==================
    // Evita XSS ao inserir texto vindo da API no HTML
    function esc(texto) {
      const d = document.createElement("div");
      d.textContent = texto ?? "";
      return d.innerHTML;
    }

    function formatarData(valor) {
      if (!valor) return "-";
      const [ano, mes, dia] = String(valor).slice(0, 10).split("-");
      return `${dia}/${mes}/${ano}`;
    }

    let toastTimer;
    function avisar(mensagem, erro = false) {
      const t = $("toast");
      t.textContent = mensagem;
      t.className = "show" + (erro ? " error" : "");
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => (t.className = ""), 3500);
    }

    // Função única para falar com a API, com tratamento de erros
    async function api(url, opcoes = {}) {
      let resposta;
      try {
        resposta = await fetch(url, {
          headers: { "Content-Type": "application/json" },
          ...opcoes,
        });
      } catch {
        throw new Error("Não foi possível conectar ao servidor. Verifique se a API está rodando.");
      }
      let dados = null;
      try { dados = await resposta.json(); } catch { /* resposta sem corpo (ex.: 204) */ }
      if (!resposta.ok) {
        throw new Error(dados?.erro || dados?.message || `Erro ${resposta.status} na requisição.`);
      }
      return dados;
    }

    // ================== READ: listar ==================
    async function carregar() {
      try {
        objetos = await api(ROTA);
        renderizar();
      } catch (e) {
        $("lista").innerHTML = `<div class="empty">${esc(e.message)}</div>`;
        avisar(e.message, true);
      }
    }

    function renderizar() {
      const termo = $("busca").value.trim().toLowerCase();
      const filtro = $("filtro").value;

      const visiveis = objetos.filter((o) => {
        const texto = `${o.descricao} ${o.categoria} ${o.local}`.toLowerCase();
        return texto.includes(termo) && (!filtro || o.situacao === filtro);
      });

      if (!visiveis.length) {
        $("lista").innerHTML = `<div class="empty">${objetos.length ? "Nenhum objeto encontrado com esses filtros."
            : "Nenhum objeto cadastrado ainda. Use o formulário para registrar o primeiro."
          }</div>`;
        return;
      }

      $("lista").innerHTML = visiveis.map((o) => {
        const devolvido = o.situacao === "devolvido";
        return `
        <article class="item ${devolvido ? "devolvido" : ""}">
          <h3>${esc(o.descricao)}</h3>
          <p class="meta">${esc(o.categoria)} · ${esc(o.local)} · ${formatarData(o.data_registro)}</p>
          <span class="badge">${esc(o.situacao)}</span>
          <div class="actions">
            <button class="ghost" data-acao="ver" data-id="${o.id}">Ver detalhes</button>
            <button class="ghost" data-acao="status" data-id="${o.id}">
              ${devolvido ? "Marcar como disponível" : "Marcar como devolvido"}
            </button>
            <button class="danger" data-acao="excluir" data-id="${o.id}">Excluir</button>
          </div>
        </article>`;
      }).join("");
    }

    // ================== CREATE: cadastrar ==================
    function validar(dados) {
      const erros = {};
      if (!dados.descricao.trim()) erros.descricao = "Informe a descrição do objeto.";
      if (!dados.categoria) erros.categoria = "Selecione uma categoria.";
      if (!dados.local.trim()) erros.local = "Informe onde o objeto foi encontrado.";
      if (!dados.data_registro) erros.data_registro = "Informe a data do registro.";
      return erros;
    }

    function mostrarErros(erros) {
      document.querySelectorAll(".field-error").forEach((el) => {
        el.textContent = erros[el.dataset.for] || "";
      });
    }

    form.addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const dados = {
        descricao: form.descricao.value.trim(),
        categoria: form.categoria.value,
        local: form.local.value.trim(),
        data_registro: form.data_registro.value,
        situacao: "disponível",
      };

      const erros = validar(dados);
      mostrarErros(erros);
      if (Object.keys(erros).length) return;

      const botao = $("btn-salvar");
      botao.disabled = true;
      try {
        await api(ROTA, { method: "POST", body: JSON.stringify(dados) });
        form.reset();
        definirDataHoje();
        avisar("Objeto cadastrado.");
        await carregar();
      } catch (e) {
        avisar(e.message, true);
      } finally {
        botao.disabled = false;
      }
    });

    // ================== READ por id / UPDATE / DELETE ==================
    $("lista").addEventListener("click", async (ev) => {
      const botao = ev.target.closest("button[data-acao]");
      if (!botao) return;
      const id = botao.dataset.id;

      try {
        if (botao.dataset.acao === "ver") {
          const o = await api(`${ROTA}/${id}`);
          $("detalhes-corpo").innerHTML = `
          <dt>Descrição</dt><dd>${esc(o.descricao)}</dd>
          <dt>Categoria</dt><dd>${esc(o.categoria)}</dd>
          <dt>Local encontrado</dt><dd>${esc(o.local)}</dd>
          <dt>Data do registro</dt><dd>${formatarData(o.data_registro)}</dd>
          <dt>Situação</dt><dd>${esc(o.situacao)}</dd>`;
          $("detalhes").showModal();
        }

        if (botao.dataset.acao === "status") {
          const atual = objetos.find((o) => String(o.id) === String(id));
          const novo = atual.situacao === "devolvido" ? "disponível" : "devolvido";
          await api(`${ROTA}/${id}`, { method: "PATCH", body: JSON.stringify({ situacao: novo }) });
          avisar(`Situação alterada para ${novo}.`);
          await carregar();
        }

        if (botao.dataset.acao === "excluir") {
          if (!confirm("Excluir este objeto? Essa ação não pode ser desfeita.")) return;
          await api(`${ROTA}/${id}`, { method: "DELETE" });
          avisar("Objeto excluído.");
          await carregar();
        }
      } catch (e) {
        avisar(e.message, true);
      }
    });

    $("fechar-detalhes").addEventListener("click", () => $("detalhes").close());
    $("busca").addEventListener("input", renderizar);
    $("filtro").addEventListener("change", renderizar);

    // ================== INICIALIZAÇÃO ==================
    function definirDataHoje() {
      const hoje = new Date();
      const local = new Date(hoje.getTime() - hoje.getTimezoneOffset() * 60000);
      $("data_registro").value = local.toISOString().slice(0, 10);
    }

    definirDataHoje();
    carregar();